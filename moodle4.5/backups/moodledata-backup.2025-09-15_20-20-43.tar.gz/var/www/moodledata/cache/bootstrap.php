<?php
// ********** This file is generated DO NOT EDIT **********
$CFG->siteidentifier = '605nE6CtDIXoiQdnKX0aGa5uiLSL7gwTlocalhost';
$CFG->bootstraphash = '9cb5bb7c44d4ba2b3fa33a99fa54e991';
// Only if the file is not stale and has not been defined.
if ($CFG->bootstraphash === hash_local_config_cache() && !defined('SYSCONTEXTID')) {
    define('SYSCONTEXTID', 1);
}
